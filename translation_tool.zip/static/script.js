function translateText() {
  const text = document.getElementById("inputText").value;
  const sourceLang = document.getElementById("sourceLang").value;
  const targetLang = document.getElementById("targetLang").value;

  fetch("http://localhost:5000/translate", {
    method: "POST",
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({text, source_lang: sourceLang, target_lang: targetLang})
  })
  .then(res => res.json())
  .then(data => {
    document.getElementById("translatedText").innerText = data.translated_text;
    loadHistory();
  });
}

function loadHistory() {
  fetch("http://localhost:5000/history")
    .then(res => res.json())
    .then(data => {
      const historyList = document.getElementById("historyList");
      historyList.innerHTML = "";
      data.forEach(entry => {
        const li = document.createElement("li");
        li.textContent = `${entry.source_text} → ${entry.translated_text} [${entry.source_lang} → ${entry.target_lang}]`;
        historyList.appendChild(li);
      });
    });
}

function startDictation() {
  const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
  recognition.lang = 'en-US';
  recognition.onresult = function(event) {
    document.getElementById("inputText").value = event.results[0][0].transcript;
  };
  recognition.start();
}

function speakText() {
  const text = document.getElementById("translatedText").innerText;
  const msg = new SpeechSynthesisUtterance(text);
  window.speechSynthesis.speak(msg);
}

window.onload = loadHistory;