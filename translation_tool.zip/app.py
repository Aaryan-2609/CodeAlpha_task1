from flask import Flask, request, jsonify
from flask_cors import CORS
import requests
import sqlite3
from datetime import datetime

app = Flask(__name__)
CORS(app)

# Database setup
def init_db():
    conn = sqlite3.connect('translations.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS translations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_text TEXT,
                    translated_text TEXT,
                    source_lang TEXT,
                    target_lang TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )''')
    conn.commit()
    conn.close()

@app.route('/translate', methods=['POST'])
def translate():
    data = request.json
    text = data.get('text')
    source_lang = data.get('source_lang', 'auto')
    target_lang = data.get('target_lang', 'en')

    response = requests.post("https://libretranslate.de/translate", data={
        "q": text,
        "source": source_lang,
        "target": target_lang,
        "format": "text"
    })
    result = response.json()
    translated_text = result.get("translatedText", "")

    # Save to database
    conn = sqlite3.connect('translations.db')
    c = conn.cursor()
    c.execute("INSERT INTO translations (source_text, translated_text, source_lang, target_lang) VALUES (?, ?, ?, ?)",
              (text, translated_text, source_lang, target_lang))
    conn.commit()
    conn.close()

    return jsonify({"translated_text": translated_text})

@app.route('/history', methods=['GET'])
def history():
    conn = sqlite3.connect('translations.db')
    c = conn.cursor()
    c.execute("SELECT source_text, translated_text, source_lang, target_lang, timestamp FROM translations ORDER BY timestamp DESC LIMIT 10")
    rows = c.fetchall()
    conn.close()

    history_list = [
        {"source_text": r[0], "translated_text": r[1], "source_lang": r[2], "target_lang": r[3], "timestamp": r[4]}
        for r in rows
    ]
    return jsonify(history_list)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)